# Khushbu Perfume Order Website (v1 prototype)

Customer storefront + staff login with admin/moderator role separation.

## Included
- Bengali customer product list and order form
- Orders saved in SQLite
- Admin and moderator login with server-side role checks
- Admin-only product management (retail price and product cost)
- Order status changes for admin/moderator
- Per-order gross product profit and percentage estimate
- Admin summary report
- CSV export is not yet implemented in admin dashboard
- Uses the supplied Khushbu logo and shop photo

## Important before real launch
This is a deployable starter project, not yet a fully audited production e-commerce system. The initial product catalog is sample data. Replace all sample products/prices/costs. Delivery is set to zero in customer checkout and should be confirmed with the customer by staff; profit currently excludes delivery, packaging, payment fees, salaries, promotions and other overhead. Do not describe it as net profit until those costs are included.
The session store is Express's default MemoryStore, which is not suitable for multi-process production hosting. Use a persistent session store, HTTPS, automated database backups, and a production hosting environment before public launch. Configure privacy notice, order retention, support/contact details and terms. Test the system and restore backups before accepting real orders.

## Requirements
- Node.js 20+
- npm
- Hosting that supports a persistent writable disk for `data/` (SQLite database)
- HTTPS for public deployment

## Run locally
1. Copy `.env.example` to `.env`.
2. Set `SESSION_SECRET` to a long random value (32+ characters).
3. Change admin and moderator usernames/passwords to unique strong values.
4. Run `npm install`
5. Run `npm start`
6. Open `http://localhost:3000`

The first start creates accounts from `.env` and sample products. Existing accounts are not overwritten by later `.env` changes; update credentials securely through a future user-management flow or database maintenance. Never share the `.env` file.

## Routes
- `/` customer order site
- `/admin` staff login
- `/api/orders` creates a customer order
- `/api/orders` GET is staff-only
- `/api/admin/products` admin-only
- `/api/reports` admin-only
- `/health` health check

## Profit formula
`profit = order total - sum(product cost × quantity)`
`profit % = profit / order total × 100`
This is currently a product-level contribution estimate, not net profit after all operating costs.

## Suggested production checklist
- Set up persistent session storage and secure cookie settings behind HTTPS.
- Configure database backups and a tested restore procedure.
- Add CSRF protection and stricter phone validation.
- Add order/customer export and admin audit log.
- Add delivery fee, discounts, payment status and full cost tracking.
- Add privacy policy, consent text, customer support phone and returns/delivery policies.
- Add separate staff account management and password reset.
- Add order notification to WhatsApp/email after confirming a provider.
